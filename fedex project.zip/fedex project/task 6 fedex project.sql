---Latest Status of Each Shipment + Latest Delivery Date
SELECT
    Shipment_ID,
    Delivery_Status,
    Delivery_Date
FROM Shipments;

---Routes with Many “In Transit” or “Returned” Shipments
SELECT
    Route_ID,
    COUNT(*) AS Total_Shipments,
    SUM(CASE WHEN Delivery_Status = 'In Transit' THEN 1 ELSE 0 END) AS In_Transit_Count,
    SUM(CASE WHEN Delivery_Status = 'Returned' THEN 1 ELSE 0 END) AS Returned_Count
FROM Shipments
GROUP BY Route_ID
HAVING In_Transit_Count > 0 OR Returned_Count > 0;

----Most Frequent Delay Reasons
SELECT
    Delay_Reason,
    COUNT(*) AS Frequency
FROM Shipments
WHERE Delay_Reason IS NOT NULL AND Delay_Reason <> ''
GROUP BY Delay_Reason
ORDER BY Frequency DESC;

----Shipments With Extremely High Delay (>120 Hours)
SELECT 
    Shipment_ID,
    Route_ID,
    Warehouse_ID,
    Delay_Hours,
    Delivery_Status
FROM Shipments
WHERE Delay_Hours > 120;



