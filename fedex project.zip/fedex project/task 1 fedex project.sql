use `project fedex`;
show tables;

ALTER TABLE Orders ADD COLUMN temp_id INT AUTO_INCREMENT PRIMARY KEY;
DELETE t1
FROM Orders t1
JOIN Orders t2
ON t1.Order_ID = t2.Order_ID
AND t1.temp_id > t2.temp_id;
DELETE s1
FROM Shipments s1
JOIN Shipments s2
ON s1.Shipment_ID = s2.Shipment_ID
AND s1.temp_id > s2.temp_id;
UPDATE Shipments s
SET Delay_Hours = (
    SELECT AVG(Delay_Hours)
    FROM Shipments
    WHERE Route_ID = s.Route_ID
)
WHERE Delay_Hours IS NULL;
UPDATE Orders
SET Order_Date = STR_TO_DATE(Order_Date, '%Y-%m-%d %H:%i:%s');

UPDATE Shipments
SET Pickup_Date = STR_TO_DATE(Pickup_Date, '%Y-%m-%d %H:%i:%s'),
    Delivery_Date = STR_TO_DATE(Delivery_Date, '%Y-%m-%d %H:%i:%s');
    SELECT Shipment_ID, Pickup_Date, Delivery_Date
FROM Shipments
WHERE Delivery_Date < Pickup_Date;
SELECT Order_ID FROM Shipments WHERE Order_ID NOT IN (SELECT Order_ID FROM Orders);
SELECT Route_ID FROM Shipments WHERE Route_ID NOT IN (SELECT Route_ID FROM Routes);
SELECT Warehouse_ID FROM Shipments WHERE Warehouse_ID NOT IN (SELECT Warehouse_ID FROM Warehouses);
SELECT Agent_ID FROM Shipments WHERE Agent_ID NOT IN (SELECT Agent_ID FROM Delivery_Agents);

select* from orders;




