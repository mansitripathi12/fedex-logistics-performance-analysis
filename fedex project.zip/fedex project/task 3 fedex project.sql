----Average Transit Time per Route
SELECT 
    s.Route_ID,
    AVG(TIMESTAMPDIFF(HOUR, s.Pickup_Date, s.Delivery_Date)) AS Avg_Transit_Time
FROM Shipments s
GROUP BY s.Route_ID;

---Average Delay per Route
SELECT 
    Route_ID,
    AVG(Delay_Hours) AS Avg_Delay
FROM Shipments
GROUP BY Route_ID;

---Distance-to-Time Efficiency Ratio
SELECT 
    r.Route_ID,
    r.Distance_KM,
    r.Avg_Transit_Time_Hours,
    (r.Distance_KM / r.Avg_Transit_Time_Hours) AS Efficiency_Ratio
FROM Routes r;

----Worst Efficiency Routes (Lowest Ratio)
SELECT 
    r.Route_ID,
    r.Distance_KM,
    r.Avg_Transit_Time_Hours,
    (r.Distance_KM / r.Avg_Transit_Time_Hours) AS Efficiency_Ratio
FROM Routes r
ORDER BY Efficiency_Ratio ASC
LIMIT 3;

----Routes Where >20% Shipments Are Delayed
SELECT
    Route_ID,
    COUNT(*) AS Total_Shipments,
    SUM(CASE WHEN Delay_Hours > 0 THEN 1 ELSE 0 END) AS Delayed_Shipments,
    (SUM(CASE WHEN Delay_Hours > 0 THEN 1 ELSE 0 END) / COUNT(*)) * 100 AS Delay_Percentage
FROM Shipments
GROUP BY Route_ID
HAVING Delay_Percentage > 20;

