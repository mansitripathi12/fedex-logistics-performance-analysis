-----Rank Delivery Agents (Per Route) by On-Time Delivery %

SELECT
    s.Agent_ID,
    s.Route_ID,
    COUNT(*) AS Total_Shipments,
    SUM(CASE WHEN s.Delay_Hours = 0 THEN 1 ELSE 0 END) AS On_Time_Shipments,
    (SUM(CASE WHEN s.Delay_Hours = 0 THEN 1 ELSE 0 END) / COUNT(*)) * 100 AS On_Time_Percentage,
    RANK() OVER (PARTITION BY s.Route_ID ORDER BY (SUM(CASE WHEN s.Delay_Hours = 0 THEN 1 ELSE 0 END) / COUNT(*)) * 100 DESC) AS Agent_Rank
FROM Shipments s
GROUP BY s.Agent_ID, s.Route_ID;

----Find Agents With On-Time % Below 85%
SELECT
    s.Agent_ID,
    COUNT(*) AS Total_Shipments,
    SUM(CASE WHEN s.Delay_Hours = 0 THEN 1 ELSE 0 END) AS On_Time_Shipments,
    (SUM(CASE WHEN s.Delay_Hours = 0 THEN 1 ELSE 0 END) / COUNT(*)) * 100 AS On_Time_Percentage
FROM Shipments s
GROUP BY s.Agent_ID
HAVING On_Time_Percentage < 85;

---Top 5 Agents (Best On-Time Delivery)
WITH AgentPerformance AS (
    SELECT
        s.Agent_ID,
        (SUM(CASE WHEN s.Delay_Hours = 0 THEN 1 ELSE 0 END) / COUNT(*)) * 100 AS On_Time_Percentage
    FROM Shipments s
    GROUP BY s.Agent_ID
)

SELECT 
    ap.Agent_ID, 
    da.Agent_Name,
    da.Experience_Years,
    da.Avg_Rating,
    ap.On_Time_Percentage
FROM AgentPerformance ap
JOIN Delivery_Agents da ON ap.Agent_ID = da.Agent_ID
ORDER BY ap.On_Time_Percentage DESC
LIMIT 5;

----Bottom 5 Agents (Worst On-Time Delivery)
WITH AgentPerformance AS (
    SELECT
        s.Agent_ID,
        (SUM(CASE WHEN s.Delay_Hours = 0 THEN 1 ELSE 0 END) / COUNT(*)) * 100 AS On_Time_Percentage
    FROM Shipments s
    GROUP BY s.Agent_ID
)

SELECT 
    ap.Agent_ID, 
    da.Agent_Name,
    da.Experience_Years,
    da.Avg_Rating,
    ap.On_Time_Percentage
FROM AgentPerformance ap
JOIN Delivery_Agents da ON ap.Agent_ID = da.Agent_ID
ORDER BY ap.On_Time_Percentage ASC
LIMIT 5;
select* from shipments;


