----Average Delivery Delay per Source Country

i join Shipments + Routes to connect delay with source country.
SELECT
    r.Source_Country,
    AVG(s.Delay_Hours) AS Avg_Delay_Hours
FROM Shipments s
JOIN Routes r ON s.Route_ID = r.Route_ID
GROUP BY r.Source_Country
ORDER BY Avg_Delay_Hours DESC;

---On-Time Delivery %
SELECT
    COUNT(*) AS Total_Deliveries,
    SUM(CASE WHEN Delay_Hours = 0 THEN 1 ELSE 0 END) AS On_Time_Deliveries,
    (SUM(CASE WHEN Delay_Hours = 0 THEN 1 ELSE 0 END) / COUNT(*)) * 100 AS On_Time_Percentage
FROM Shipments;

---Average Delay per Route

SELECT
    Route_ID,
    AVG(Delay_Hours) AS Avg_Delay_Hours
FROM Shipments
GROUP BY Route_ID
ORDER BY Avg_Delay_Hours DESC;

---Warehouse Utilization Percentage

Utilization =
👉 Shipments Handled / Capacity per Day × 100
SELECT
    w.Warehouse_ID,
    w.Capacity_per_day,
    COUNT(s.Shipment_ID) AS Shipments_Handled,
    (COUNT(s.Shipment_ID) / w.Capacity_per_day) * 100 AS Utilization_Percentage
FROM Warehouses w
LEFT JOIN Shipments s ON w.Warehouse_ID = s.Warehouse_ID
GROUP BY w.Warehouse_ID, w.Capacity_per_day;

----Delay % per Delivery Type:
SELECT
    o.Delivery_Type,
    (SUM(CASE WHEN s.Delay_Hours > 0 THEN 1 ELSE 0 END) / COUNT(*)) * 100 AS Delay_Percentage
FROM Shipments s
JOIN Orders o ON s.Order_ID = o.Order_ID
GROUP BY o.Delivery_Type;

select* from shipments;



