----calculate delay delivery
SELECT 
    Shipment_ID,
    TIMESTAMPDIFF(HOUR, Pickup_Date, Delivery_Date) AS Calculated_Delay_Hours
FROM Shipments;

-----top 10 delayed routes
SELECT 
    Route_ID,
    AVG(Delay_Hours) AS Avg_Delay
FROM Shipments
GROUP BY Route_ID
ORDER BY Avg_Delay DESC
LIMIT 10;

----Rank shipments by delay within each Warehouse
SELECT 
    Shipment_ID,
    Warehouse_ID,
    Delay_Hours,
    RANK() OVER (PARTITION BY Warehouse_ID ORDER BY Delay_Hours DESC) AS Delay_Rank
FROM Shipments;

---Average delay per Delivery Type
SELECT 
    o.Delivery_Type,
    AVG(s.Delay_Hours) AS Avg_Delay
FROM Shipments s
JOIN Orders o
    ON s.Order_ID = o.Order_ID
GROUP BY o.Delivery_Type;
select* from shipments;

