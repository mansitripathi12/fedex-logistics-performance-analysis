----Top 3 Warehouses With Highest Average Delay
SELECT 
    Warehouse_ID,
    AVG(Delay_Hours) AS Avg_Delay
FROM Shipments
GROUP BY Warehouse_ID
ORDER BY Avg_Delay DESC
LIMIT 3;

----Total Shipments vs Delayed Shipments Per Warehouse
SELECT 
    Warehouse_ID,
    COUNT(*) AS Total_Shipments,
    SUM(CASE WHEN Delay_Hours > 0 THEN 1 ELSE 0 END) AS Delayed_Shipments
FROM Shipments
GROUP BY Warehouse_ID;

----Warehouses Where Avg Delay > Global Average (Using CTE)
WITH GlobalAvg AS (
    SELECT AVG(Delay_Hours) AS Global_Avg_Delay
    FROM Shipments
);

SELECT 
    s.Warehouse_ID,
    AVG(s.Delay_Hours) AS Warehouse_Avg_Delay,
    g.Global_Avg_Delay
FROM Shipments s, GlobalAvg g
GROUP BY s.Warehouse_ID
HAVING Warehouse_Avg_Delay > g.Global_Avg_Delay;

---Rank Warehouses by On-Time Delivery %

SELECT
    Warehouse_ID,
    COUNT(*) AS Total_Shipments,
    SUM(CASE WHEN Delay_Hours = 0 THEN 1 ELSE 0 END) AS On_Time_Shipments,
    (SUM(CASE WHEN Delay_Hours = 0 THEN 1 ELSE 0 END) / COUNT(*)) * 100 AS On_Time_Percentage,
    RANK() OVER (ORDER BY (SUM(CASE WHEN Delay_Hours = 0 THEN 1 ELSE 0 END) / COUNT(*)) * 100 DESC) AS Rank_On_Time
FROM Shipments
GROUP BY Warehouse_ID;

